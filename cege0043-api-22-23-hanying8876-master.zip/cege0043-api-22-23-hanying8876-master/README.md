# Condition Assessment App
  A technical guide for a browser-based question setting condition assessment app.This app helps the user to solve some questions about how to use this app.
  By using this application, the location of an asset can be entered by clicking on a point on a flyer map or by manually entering latitude and longitude, and the application is also with the ability to retrieve certain characteristics and information about the user from a database.

---
## Table of Contents
1. [System Requirements](#system-requirements)
2. [Deployment](#deployment)
3. [Testing](#testing)
4. [File description](#file-description)
5. [Code reference](#code-reference)

---

## 1. System Requirements<a name="system-requirements"></a>
- **This app needs to connect to an Ubuntu server (virtual machine). You can use BitVise, Pycharm (version 2018.3.5 Professional) or other SSH software to link to the Ubuntu server.**
- **If you are planning to use this app off the University College London campus (without a connection to Edu Roaming), please ensure that you have followed the instructions on https://www.ucl.ac.uk/isd/services/get-connected/remote-working-services/ucl- instructions on virtualprivate-network-vpn. to connect to University College London's VPN.**

- **In order to activate the full functionality of this app, a browser that allows geolocation access via an http connection is required. Some browsers (e.g. Safari) will refuse geolocation access via an http connection. As a result, the app will not be unable to locate and zoom in on the user's location if opened in one of these browsers. Therefore, It is RECOMMENDED to use Chrome (version 73.0.3683.75 or above) or Firefox (version 65.0.2 or above) in this app.**

[⬆ back to top](#table-of-contents)

---
## 2. Deployment<a name="deployment"></a>
- **Procedures to test this app:**

1.Clone the source code of this asset setup app from Github to the CEGE server/student user/code in your home by entering in Ubuntu's command line (terminal) window:

`cd home/hanyinli/code`

`git clone https://github.com/ucl-geospatial-22-23/cege0043-api-22-23-hanying8876.git`

2.Clone the source code of the corresponding Node JS server from Github to the CEGE server at home/hanyinli/code/cege0043-apps-22-23-hanying8876：

`cd home/hanyinli/code`

`git clone https://github.com/ucl-geospatial-22-23/cege0043-apps-22-23-hanying8876.git`

3.Go to the cege0043-apps-22-23-hanying8876 folder and start the Node JS server:

`cd home/hanyinli/code/cege0043-apps-22-23-hanying8876`

`pm2 start app.js`

4.Please ensure that the Node JS server has been successfully started. If any errors occur, you can enter DEBUG mode via a command line window by typing:

`cd home/hanyinli/code/cege0043-apps-22-23-hanying8876`

`node app.js`

[⬆ back to top](#table-of-contents)
---
## 3. Testing<a name="testing"></a>
- **Procedures to test this app:**

1. Please ensure that your equipment is connected to UCL Wifi or UCL VPN. 

2. Please ensure that the Node JS server is ACTIVE. 

3. In a web browser that supports access to geolocation via an http connection (e.g. Firefox), type in the following address to use the problem settings:
`app.http://developer.cege.ucl.ac.uk:30313/uceslxw-questions/www/index.html`

4. Please sure to use your browser's check or Developer mode to see if any errors occur when testing the functionality of this mapping.

[⬆ back to top](#table-of-contents)
---
## 4. File description<a name="file-description"></a>
The files associated to this condition assessment app are located in the cege0043-apps-22-23-hanying8876 folder and several sub-folders.
- **~/cege0043-apps-22-23-hanying8876**
    - bootStrap.html: The main html file of this app, through which user could use all the condition assessment functionality. It interconnects all of the resources within the ~/cege0043-apps-22-23-hanying8876 folder and makes use of them. This html contains several divs and menu buttons.
        - Div:

          | id | description |
          | :---: | :---: |
          | mapid | Hold the leaflet map. |
          | tablediv | Add table format. |
          | mapWrapper | Wrap map width. |
          | assetDataWrapper | Wrap text to a asset data width |
          | screenwidth | Wrap screen widthp. |
          
          
        - Button:

          | name | description |
          | :---: | :---: |
          | List of Assets in Best Condition | Show List of Assets in Best Condition. |
          | Daily Reporting Rates Graph –All Users | Show  a graph about Daily Reporting Rates  –All Users. |
          | Help | Link to help page. |
          | User Ranking | Load the current ranking of the number of user assets. |
          | Add 5 closest assets | Show  points about 5 closest assets created by the current user. |
          | Remove 5 closest assets | Remove the existing  points about 5 closest assets created by the current user. |
          | Add last 5 reports | Show points  about last 5 reports created by the current user. |
          | Remove last 5 reports | Remove the existing  points  about last 5 reports created by the current user. |
          | Add not rated in the last 3 days | Show the points about not rated in the last 3 dayscreated by the current user. |
          | Remove not rated in the last 3 days | Remove the existing points about not rated in the last 3 dayscreated by the current user. |
  
  - help.html : The help HTML file for this application, through which users can learn how to use the indexi.html page. It interlinks all the resources within the ~/cege0043-apps-22-23-hanying8876 folder and makes use of them.

          
- **~/cege0043-apps-22-23-hanying8876/css:** Setting up styles of bootStrap.html (such as fonts and margins) and incorporating the CSS required for custom icon creation.
- **~/cege0043-apps-22-23-hanying8876/img:** Containing images required by bootStrap.html.
- **~/cege0043-apps-22-23-hanying8876/lib:**
- **~/cege0043-apps-22-23-hanying8876/scss:**
- **~/cege0043-apps-22-23-hanying8876/js:** Containing Javascript files required by bootStrap.html.
    - utilities.js 
    - userTracking.js 
    
      | function | description |
      | :---: | :---: |
      | trackLocation() | Track user's current location.|
      | showPosition() | Display user's location on the map, including a display of the nearest point to the user and a pop-up window showing information about that point|
      | errorPosition() | Report an error.|
      | calculateDistance() | Calculate the distance from the user's location to the asset.|
      | removePositionPoints() | Remove user's current location point.|
      | removeTracks() | Remove user's current location.|
      | userZoom() | If the user's location is available, zoom and focus the map to the user's current location. If user position is undefined, generate an alert. Generate an alert if no mapping layer is loaded, i.e. when the D3 graphic is displayed.|
      
      
    - uploadData.js 
    
      | function | description |
      | :---: | :---: |
      | saveNewAsset()| Collect the asset data entered by the user. If the user does not fill in all the required fields, or if there are duplicate values, an error message will appear. |
      | deleteSingleAsset() | Tell the server what type of data we are delete  the data.|
      | dataDeleteResult() | Delete data based on id.|
      | getPreviousCon() | Get the previous asset condition information and save it.|
      | saveConditionInformation() | Save asset condition information and compare it with previous condition information and report the number of reports.|
      | getReportNumber() | Get the previous Report Numbe information and save it.|
     
     

    - menu.js 

      | function | description |
      | :---: | :---: |
      | bestCondition()| Showing the best condition asset information sheet. |
      | UserRanking()  | Shows the current ranking of the number of user assets.|
      | addLayerClosest() | Get data on the 5 closest assets to the user and list these questions with the correct answers and user information.|
      | removeLayerClosest() | Remove data on the 5 closest assets to the user.|
      | addLayerClosest() | Get data where the last 5 times the user has added asset information and list these questions with the correct answers and user information.|
      | removeLayerClosest() | Remove data where the last 5 times the user has added asset information.|
      | addLayerClosest() | Get data of assets that have not been rated in the last 3 days and list these questions with the correct answers and user information.|
      | removeLayerClosest() | Remove data of assets that have not been rated in the last 3 days.|
      
    - graph.js
    
      | function | description |
      | :---: | :---: |
      | closeAssetData()| Close the asset data and map blocks on the page, using the Bootstrap framework's Collapse plugin to achieve the collapse and expansion effect. |
      | loadGraph() | Loading a table on a page.|
      | createGraph() | Create table formats.|
      | wrap() | Wrap text to a specified width, implemented using the D3 library.|
     
    
    
    - basicMap.js 

      | function | description |
      | :---: | :---: |
      | processWindowResize()| Collect the asset data entered by the user. If the user does not fill in all the required fields, or if there are duplicate values, an error message will appear. |
      | refreshMap() | Refresh Map.|
      | loadMap() | Loading map leaflet.|
      | removeAllLayers() | This is useful when multiple layers are loaded and it is difficult to delete one layer at a time. It will delete all layers except the base mapping and the user location marker if both have been loaded. It will also generate an alert if no containers have been initialised.|
      | getUserId() | Get user's current ID.|
      | setMapClickEvent() | Screen size change for different functions.|
      | setUpPointClick() | Click on the marker to display the assets form.|
      | getConditionPopupHTML() | Create the assets condition form.|
      | getAssetPopupHTML | Create the assets information form.|
      | loadAssets() | Load asset point layers and display different colours depending on the state of the asset.|
      | CurrentUserAssetPoints() | Load asset point layers.|
      | onMapClick() | When the user clicks on the map, the asset information sheet is displayed at the clicked location and the coordinates of the clicked location are automatically entered.|
      | assetFormHtml() | Load the asset information shee.|
      
  
  - dashboard.html: The dashboard.html file of this app, through which user could use all the condition assessment functionality, including visual representations such as geometric shapes and 3D visualisations. It interconnects all of the resources within the ~/cege0043-apps-22-23-hanying8876 folder and makes use of them.


  
[⬆ back to top](#table-of-contents)
---
## 5. Code reference<a name="code-reference"></a>
- **A large proportion of codes are adapted from the lab notes of CEGE 0043 Web Mobile andGIS by Calire Ellul, including:**
     - Basic structures of index.html
     - Functions related to events detector, data loading, data uploading, data processing, user location tracking, displaying map layers, and getting port numbers.
     
- **The histograms showing daily user participation utilise D3 JavaScript library.**

- **The base map data is based on Open Street Map.**


- **The layers of this app are based on Leaflet.**


- **The user interface of this app are based on Material design Lite Dashboard.**

[⬆ back to top](#table-of-contents)
