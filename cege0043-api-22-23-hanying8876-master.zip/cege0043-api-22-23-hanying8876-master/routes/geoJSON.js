"use strict"; 
const express = require('express');
 const pg = require('pg');
 const geoJSON = require('express').Router();
 const fs = require('fs');
 
 // get the username - this will ensure that we can use the same code on multiple machines
 const os = require('os');
 const userInfo = os.userInfo();
 const username = userInfo.username;
 console.log(username);
 // locate the database login details
 const configtext = ""+fs.readFileSync("/home/"+username+"/certs/postGISConnection.js");
 
 // now convert the configuration file into the correct format -i.e. a name/value pair array
 const configarray = configtext.split(",");
 let config = {};
 for (let i = 0; i < configarray.length; i++) {
 let split = configarray[i].split(':');
 config[split[0].trim()] = split[1].trim();
 }
 const pool = new pg.Pool(config);
 console.log(config);
 
 
 
 geoJSON.route('/testGeoJSON').get(function (req,res) {
 res.json({message:req.originalUrl});
 });
 

 
 geoJSON.get('/postgistest', function (req,res) { 
 pool.connect(function(err,client,done) { 
 if(err){ console.log("not able to get connection "+ err); res.status(400).send(err); } 
 client.query(' select * from information_schema.columns' ,function(err,result) { 
 done(); if(err){ console.log(err); res.status(400).send(err); } 
 res.status(200).send(result.rows); }); }); });
 

 
 geoJSON.get('/:schemaname/:tablename/:idcolumn/:geomcolumn', function (req,res) { 
pool.connect(function(err,client,done) { 
if(err){ 
console.log("not able to get connection "+ err); 
res.status(400).send(err); 
} 
let colnames = ""; 
// first get a list of the columns that are in the table 
// use string_agg to generate a comma separated list that can then be pasted into the next query 
let tablename = req.params.tablename; 
let schema = req.params.schemaname; 
let idcolumn = req.params.idcolumn; 
let geomcolumn = req.params.geomcolumn; 
let geomcolumnJSON = JSON.stringify(geomcolumn); 
let tablenameJSON = schema+"."+tablename; 
let querystring = "select string_agg(colname,',') from ( select column_name as colname "; 
querystring = querystring + " FROM information_schema.columns as colname "; 
querystring = querystring + " where table_name =$1"; 
querystring = querystring + " and column_name <> $2 and table_schema = $3 and data_type <> 'USER-DEFINED') as cols "; 
console.log(querystring); 
// now run the query 
client.query(querystring,[tablename,geomcolumn,schema], function(err,result){ 
if(err){ 
console.log(err); 
res.status(400).send(err); 
} 
let thecolnames = result.rows[0].string_agg; 
colnames = thecolnames; 
console.log("the colnames "+thecolnames); 
// SQL injection prevention - check that the ID column exists 
if (thecolnames.toLowerCase().indexOf(idcolumn.toLowerCase()) > -1) { 
let cols = colnames.split(","); 
let colString=""; 
for (let i =0; i< cols.length;i++){ 
console.log(cols[i]); 
colString = colString + JSON.stringify(cols[i]) + ","; 
} 
console.log(colString); 
//remove the extra comma 
colString = colString.substring(0,colString.length -1); 
// now use the inbuilt geoJSON functionality 
// and create the required geoJSON format using a query adapted from here:
// http://www.postgresonline.com/journal/archives/267-Creating-GeoJSON-Feature-Collections-with-JSON-and-PostGIS-functions.html, accessed 4th January 2018 
// note that query needs to be a single string with no line breaks so built it up bit by bit 
// to overcome the polyhedral surface issue, convert them to simple geometries 
// assume that all tables have an id field for now - to do add the name of the id field as a parameter 
querystring = "SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features FROM "; 
querystring += "(select 'Feature' as type, x.properties,st_asgeojson(y.geometry)::json as geometry from "; 
querystring +=" (select "+idcolumn+", row_to_json((SELECT l FROM (SELECT "+colString + ") As l )) as properties FROM "+schema+"."+JSON.stringify(tablename); 
querystring += " ) x"; 
querystring +=" inner join (SELECT "+idcolumn+", c.geom as geometry"; 
querystring +=" FROM ( SELECT "+idcolumn+", (ST_Dump(st_transform("+geomcolumn+",4326))).geom AS geom "; 
querystring +=" FROM "+schema+"."+JSON.stringify(tablename)+") c) y on y."+idcolumn+" = x."+idcolumn+") f"; 
console.log(querystring); 
client.query(querystring,function(err,result){ 
//call `done()` to release the client back to the pool 
done(); 
if(err){ 
console.log(err); 
res.status(400).send(err); 
} 
// remove the extra [ ] from the GeoJSON as this won't work with QGIS 
let geoJSONData = JSON.stringify(result.rows); 
geoJSONData = geoJSONData.substring(1); 
geoJSONData = geoJSONData.substring(0, geoJSONData.length - 1); 
console.log(geoJSONData); 
res.status(200).send(JSON.parse(geoJSONData)); 
}); // end of the geoJSON query 
} // the ID column name isn't in the list - so there is some attempt at injection 
else { 
res.status(400).send("Invalid ID column name"); 
} 
}); // end of the query to list all the columns 
}); // end of the pool 
}); // end of the function


//-- REFERENCE: A2
geoJSON.get('/userAssets/:user_id', function (req, res) { 
  pool.connect(function(err, client, done) { 
    if (err) { 
      console.log("not able to get connection " + err); 
      res.status(400).send(err); 
    } 
    let user_id = req.params.user_id;
	console.log(user_id)
    let colnames = "asset_id,asset_name,installation_date,latest_condition_report_date,condition_description,condition_id";
    let querystring = "SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features  FROM ";
    querystring += "(SELECT 'Feature' As type, ST_AsGeoJSON(lg.location)::json As geometry, ";
    querystring += "row_to_json((SELECT l FROM (SELECT "+colnames + " ) As l)) As properties";
    querystring += " FROM cege0043.asset_with_latest_condition As lg ";
    querystring += "WHERE user_id = $1 limit 100) As f ";
    client.query(querystring, [user_id], function(err,result) { 
      done(); 
      if (err) { 
        console.log(err); 
        res.status(400).send(err); 
      } else { 
        res.header("Content-Type", "application/json"); 
        console.log('Response data:', result.rows[0].features); 
        res.send(result.rows); 
      } 
    }); 
  }); 
});


//-- REFERENCE: A3


geoJSON.get('/userConditionReports/:user_id', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
        console.log("not able to get connection "+ err);
        res.status(400).send(err);
        }   

        let user_id = req.params.user_id;
        var querystring = " select array_to_json (array_agg(c)) from ";
            querystring += "(SELECT COUNT(*) AS num_reports from cege0043.asset_condition_information where user_id = $1) c";
        
        client.query(querystring,[user_id] ,function(err,result) {
        done(); 
            if(err){
            console.log(err);
            res.status(400).send(err);
            }
        res.status(200).send(result.rows);
        });
    });
});


//-- REFERENCE: S1


geoJSON.get('/userRanking/:user_id', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
        console.log("not able to get connection "+ err);
        res.status(400).send(err);
        }   

        let user_id = req.params.user_id;
        var querystring = " select array_to_json (array_agg(hh)) from ";
            querystring += "(select c.rank from (SELECT b.user_id, rank()over (order by num_reports desc) as rank from ";
            querystring += "(select COUNT(*) AS num_reports, user_id from ";
            querystring += "cege0043.asset_condition_information group by user_id) b) c ";
            querystring += "where c.user_id = $1) hh";
        
        client.query(querystring,[user_id] ,function(err,result) {
        done(); 
            if(err){
            console.log(err);
            res.status(400).send(err);
            }
        res.status(200).send(result.rows);
        });
    });
});



//-- REFERENCE: L1


geoJSON.get('/assetsInGreatCondition', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
        console.log("not able to get connection "+ err);
        res.status(400).send(err);
        }   

        let querystring = "select array_to_json (array_agg(d)) from ";
        querystring = querystring + " (select c.* from cege0043.asset_information c inner join ";
        querystring = querystring + "(select count(*) as best_condition, asset_id from cege0043.asset_condition_information where ";
        querystring = querystring + "condition_id in (select id from cege0043.asset_condition_options where condition_description like '%very good%') ";
        querystring = querystring + "group by asset_id order by best_condition desc) b ";
        querystring = querystring + "on b.asset_id = c.id) d";

        client.query(querystring, function(err,result) {
        console.log(result);
		done(); 
            if(err){
            console.log(err);
            res.status(400).send(err);
            }
        res.status(200).send(result.rows);
        });
    });
});


//-- REFERENCE: L2


geoJSON.get('/dailyParticipationRates', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
        console.log("not able to get connection "+ err);
        res.status(400).send(err);
        }   

        let querystring = "select  array_to_json (array_agg(c)) from ";
        querystring = querystring + " (select day, sum(reports_submitted) as reports_submitted, sum(not_working) as reports_not_working ";
        querystring = querystring + "from cege0043.report_summary ";
        querystring = querystring + "group by day) c  ";

        client.query(querystring, function(err,result) {
        done(); 
            if(err){
            console.log(err);
            res.status(400).send(err);
            }
        res.status(200).send(result.rows);
        });
    });
});


//-- REFERENCE: S2


geoJSON.get('/userFiveClosestAssets/:latitude/:longitude', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
            console.log("not able to get connection "+ err);
            res.status(400).send(err);
        }

        let latitude = req.params.latitude;
        let longitude = req.params.longitude;
		 console.log(longitude);
        let querystring = "SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features  FROM ";
        querystring = querystring + "(SELECT 'Feature' As type     , ST_AsGeoJSON(lg.location)::json As geometry, ";
        querystring = querystring + "row_to_json((SELECT l FROM (SELECT id, asset_name, installation_date) As l  )) As properties ";
        querystring = querystring + " FROM   (select c.* from cege0043.asset_information c ";
        querystring = querystring + "inner join (select id, st_distance(a.location, st_geomfromtext('POINT("+ longitude + " " + latitude + ")',4326)) as distance from cege0043.asset_information a ";
        querystring = querystring + "order by distance asc limit 5) b on c.id = b.id ) as lg) As f;";

        client.query(querystring,function(err,result) {
            done();
            if(err){
                console.log(err);
                res.status(400).send(err);
            }
            res.status(200).send(result.rows);
        }); 
    });
});


//-- REFERENCE: S3


geoJSON.get('/lastFiveConditionReports/:user_id', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
            console.log("not able to get connection "+ err);
            res.status(400).send(err);
        }

        let user_id = req.params.user_id;
        let querystring = "SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features  FROM ";
        querystring = querystring + "(SELECT 'Feature' As type , ST_AsGeoJSON(lg.location)::json As geometry,  ";
        querystring = querystring + "row_to_json((SELECT l FROM (SELECT id,user_id, asset_name, condition_description ";
        querystring = querystring + " ) As l  )) As properties FROM (select * from cege0043.condition_reports_with_text_descriptions ";
        querystring = querystring + "where user_id = $1 order by timestamp desc limit 5) as lg) As f;";

        client.query(querystring,[user_id],function(err,result) {
            done();
            if(err){
                console.log(err);
                res.status(400).send(err);
            }
            res.status(200).send(result.rows);
        }); 
    });
});



//-- REFERENCE: S4


geoJSON.get('/conditionReportMissing/:user_id', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
            console.log("not able to get connection "+ err);
            res.status(400).send(err);
        }

        let user_id = req.params.user_id;
        let querystring = "SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features  FROM ";
        querystring = querystring + "(SELECT 'Feature' As type     , ST_AsGeoJSON(lg.location)::json As geometry,  ";
        querystring = querystring + "row_to_json((SELECT l FROM (SELECT asset_id, asset_name, installation_date, latest_condition_report_date, condition_description) As l )) As properties FROM ";
        querystring = querystring + "(select * from cege0043.asset_with_latest_condition where user_id = $1 and asset_id not in (";
        querystring = querystring + "select asset_id from cege0043.asset_condition_information ";
        querystring = querystring + "where user_id = $1 and timestamp > NOW()::DATE-EXTRACT(DOW FROM NOW())::INTEGER-3)  ) as lg) As f;";

        client.query(querystring,[user_id],function(err,result) {
            console.log(result.rows);
			done();
            if(err){
                console.log(err);
                res.status(400).send(err);
            }
            res.status(200).json(result.rows);
        }); 
    });
});


 
module.exports = geoJSON;