"use strict";
let express = require('express'); 
let pg = require('pg'); 
let crud = require('express').Router(); 
let fs = require('fs');

let os = require('os'); const userInfo = os.userInfo(); 
const username = userInfo.username; 
console.log(username); 
// locate the database login details 
let configtext = ""+fs.readFileSync("/home/"+username+"/certs/postGISConnection.js");

// now convert the configruation file into the correct format -i.e. a name/value pair array
let configarray = configtext.split(",");
let config = {};
for (let i = 0; i < configarray.length; i++) {
let split = configarray[i].split(':');
config[split[0].trim()] = split[1].trim();
}
let pool = new pg.Pool(config);
console.log(config);

const bodyParser = require('body-parser');
crud.use(bodyParser.urlencoded({ extended: true }));

// test endpoint for GET requests (can be called from a browser URL)
crud.get('/testCRUD',function (req,res) {
        res.json({message:req.originalUrl+" " +"GET REQUEST>"});
    });
   
// test endpoint for POST requests - can only be called from AJAX
crud.post('/testCRUD',function (req,res) {
        console.log("post request" + req.body);
        res.json({message:req.body});
    });
	
//get user_id
crud.get('/userId', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
            console.log("not able to get connection "+ err);
            res.status(400).send(err);
        }
        let querystring = "select user_id from ucfscde.users where user_name = current_user;";
        console.log("Get sucessfully!")
        client.query(querystring,function(err,result) {
            done();
            if(err){
                console.log(err);
                res.status(400).send(err);
            }
            res.status(200).send(result.rows);
        }); });
});	


//A0: conditionDetails
crud.get('/conditionDetails', function (req,res) {
    pool.connect(function(err,client,done) {
        if(err){
            console.log("not able to get connection "+ err);
            res.status(400).send(err);
        }
        let querystring = "select * from cege0043.asset_condition_options;";
        console.log("Get sucessfully!")
        client.query(querystring,function(err,result) {
            done();
            if(err){
                console.log(err);
                res.status(400).send(err);
            }
            res.status(200).send(result.rows);
        }); });
});

//insert points

crud.post('/insertAssetPoint', function(req, res) {
      pool.connect(function(err, client, done) {
        if (err) {
          console.log("not able to get connection " + err);
          res.status(400).send(err);
        }

        let asset_name = req.body.asset_name;
		//console.log(asset_name)
        let installation_date = req.body.installation_date;
		
        let longitude = req.body.longitude;
        let latitude = req.body.latitude;
//console.log(latitude)

        let geometryString = "st_geomfromtext('POINT(" + longitude + " " + latitude + ")',4326)";

        let querystring = "INSERT into cege0043.asset_information (asset_name, installation_date, location) values ";
        querystring += "($1, $2, ";
		querystring += geometryString + ")";

        client.query(querystring, [asset_name, installation_date], function (err, result) {
          done();
          if (err) {
            console.log(err);
            return res.status(400).send(err); 
          }
          res.status(200).send("Asset point " + asset_name + " has been inserted.");
        });
      });
    });



crud.post('/deleteFormData',(req,res) => {
pool.connect(function(err,client,done) {
        if(err){ res.status(400).send(err);       }
    let id =  req.body.id ;
    let querystring = "DELETE from cege0043.formdata where id = $1";
    client.query( querystring,[id],function(err,result) {
                    done();
                    if(err){ res.status(400).send(err);               }     
                    res.status(200).send("If this record is yours, then form data ID "+ id+ " has been deleted.  If you did not insert this record, then no change has been made");
             });
      });
});


//A1: insert Condition Information 



crud.post('/insertConditionInformation',function(req,res){

console.log("start insert");

pool.connect(function(err,client,done) {
if(err){ 
    console.log(err);
    return res.status(400).send(err); }
let assetName = req.body.asset_name;
let conditionValue = req.body.condition_value;
console.log(assetName);
console.log(conditionValue);

let querystring = "INSERT into cege0043.asset_condition_information (asset_id, condition_id) values (";
    querystring += "(select id from cege0043.asset_information where asset_name = $1),(select id from cege0043.asset_condition_options where condition_description = $2));";
      console.log(querystring);
client.query(querystring,[assetName,conditionValue],function(err,result) { 
    done();
    console.log("done();");
    if(err){ 
        console.log("there is an error.");
          console.log(err);      
        return res.status(400).send(err); }
res.status(200).send("row inserted"); }); }); });


	
	
	
	module.exports = crud;