# cege0043-app-template
Template repository for the app (front end) code for CEGE0043
