"use strict";


function getPort() {
 console.log("resize");
  closeAssetData();
}