"use strict";


function saveNewAsset() {
	alert ("start asset data upload");
	

    // validate input data
    if (document.getElementById('asset_name').value === '') {
        alert('Please enter an asset name.');
        return false;
    }
    if (document.getElementById("installation_date").value === '') {
        alert('Please enter an installation date for your asset.');
        return false;
    }
	
	
	let asset_name = document.getElementById("asset_name").value;
	let installation_date = document.getElementById("installation_date").value;
	let user_id = document.getElementById("user_id").value;
	alert(asset_name + " "+ installation_date + " "+user_id);
	
	
	// now get the geometry values
	let latitude = document.getElementById("latitude").value;
	let longitude = document.getElementById("longitude").value;
	let postString = `asset_name=${asset_name}&installation_date=${installation_date}&latitude=${latitude}&longitude=${longitude}`;
	
if (asset_name==""||installation_date==""||latitude==""||longitude=="") {
	
	alert("Please fill out fields before submitting");
	return;


}
	
	//process Data(postString);
	let serviceUrl= document.location.origin + "/api/insertAssetPoint";
	$.ajax({
	    url: serviceUrl,
	    crossDomain: true,
	    type: "POST",
		data: postString,
	    success: function(data){console.log(data); 
		
		L.marker([latitude,longitude])
	.addTo(mymap)
	.bindPopup(`<b>${asset_name}<b><b>Installed:${installation_date}`)
	.openPopup
		
		},	
	
});	


}




function deleteSingleAsset() {
	let deleteID = document.getElementById("deleteID").value;
	let deleteString = "id="+deleteID;
	let serviceUrl= document.location.origin + "/api/testCRUD";
	$.ajax({
	    url: serviceUrl,
	    crossDomain: true,
	    type: "POST",
	    success: function(data){console.log(data); dataDeleteResult(data);},
	    data: deleteString
});	
}


function dataDeleteResult(data){
    document.getElementById("deleteAssetResponse").innerHTML = JSON.stringify(data);
}

function getPreviousCon(){
	let previous_condition;

    //now get the previous condition
    let conditionId = [];
    let conditionDescription = [];
    let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
    $.ajax({
        url: ConditionDeatailURL, crossDomain: true, success: function (result) {
            console.log(result); // check that the data is correct
            for (let i = 0; i < result.length; i++) {
                let obj = result[i];
                let id = obj.id;
                conditionId.push(id);
                let condition_description = obj.condition_description;
                conditionDescription.push(condition_description);
            }
            return previous_condition = condition_description;
        }
    });
	
}


function saveConditionInformation(previous_condition) {
  
   alert("Uploading data ");

    let asset_name = document.getElementById("asset_name").innerHTML;
    let postString = "asset_name="+asset_name;

    let current_condition;
	
    if (current_condition==previous_condition) {
        alert ("Your condition is equal to the previous condition");
    } else {
        alert ("Your condition is not equal to the previous condition");
    }

    for (let i = 1;i< 6;i++){
        if (document.getElementById(i).checked) {
            postString = postString + "&condition_value=" + document.getElementById(i).value;
            current_condition = i;
        };
    }

    

    postString = postString + "&user_id=" + document.getElementById("user_id").innerHTML;

    // checkCondition(current_condition,previousConditionValue);
    console.log(postString);
    let serviceUrl=  document.location.origin + "/api/insertConditionInformation";
    $.ajax({
        url: serviceUrl,
        crossDomain: true,
        type: "POST",
        data: postString,
        success: function(data){console.log(data);} 
    });
	getReportNumber()
    setUpPointClick();
}




function getReportNumber() {
  let idUrl = document.location.origin + "/api/userId";
  console.log(idUrl);
  $.ajax({
    url: idUrl,
    type: "GET",
    success: function (data) {
      // console.log(data);
      let userID = data[0]["user_id"];
      console.log("Your user ID is: " + userID); // Print the user ID to the console

      let current_user_id = userID;


      let serviceUrl = document.location.origin + "/api/geojson/userConditionReports/" + current_user_id;
      console.log(serviceUrl);
      $.ajax({
        url: serviceUrl,
        crossDomain: true,
        success: function (result) {
          console.log(result);
          if (result.length > 0) {
            let num_reports = result[0].array_to_json[0].num_reports;
            console.log(num_reports);

            console.log("Your report number is: " + num_reports);
            alert ("Your report number is: " + num_reports);
            
          } else {
            console.log("No reports found for user " + current_user_id);
            alert ("No reports found for user " + current_user_id);
            
          }
        }
      });
    },
    error: function (xhr, textStatus, errorThrown) {
      console.log('Error: ' + errorThrown);
    }
  });
}

