"use strict";
let mymap;
const debouncedRemover = debounce(remover, 500);
window.addEventListener('resize', debouncedRemover);

function remover(){

        console.log('Window resized');
        loadGraph();
        loadPieChart();

}

let user_id; // global variable to store the user_id when the page loads.
let baseComputerAddress = document.location.origin; // required for ajax calls.

// making sure that the first thing that takes place is the user_id being retrieved from the database
function getUserId(){

    let userIdAddress = "/api/userId";
    let userIdURL = baseComputerAddress + userIdAddress;
    $.ajax({url: userIdURL, crossDomain: true, success: function(result) {

            // Extract user_id from the response and save it in the global variable 'user_id'.
            // We can do this by putting the functionality of loading the leaflet map inside the success callback of the AJAX request.
            user_id = result[0]["user_id"];
            console.log('User ID: ' + user_id);
            
            loadConditionDescriptions();
             
          }
    })
}

let conditionDesc = [];
let conditionDescId = [];


function loadConditionDescriptions(){

    let conditionDescAddress ="/api/conditionDetails";
    let conditionDescURL = baseComputerAddress + conditionDescAddress;

    $.ajax({url: conditionDescURL, crossDomain:true, dataType: 'json', success: function(result){

        // data is an array of objects with keys "id" and "condition_description"
   
          console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionDescId.push(id);
    let condition_description = obj.condition_description;
    conditionDesc.push(condition_description);
          

          loadVectorLayer();

          loadPieChart();


        }
	}
	});
    

}


function convertDesctoInt(properties, conditionDesc, conditionDescId){
    for (let i = 0; i < properties.length; i++) {
      
      if (properties[i].condition_description === conditionDesc[0]) {
        properties[i].condition_id= conditionDescId[0];
      } 
      
      else if (properties[i].condition_description === conditionDesc[1]) {
        properties[i].condition_id = conditionDescId[1];
      }  
      
      else if (properties[i].condition_description === conditionDesc[2]) {
        properties[i].condition_id = conditionDescId[2];
      }
  
      else if (properties[i].condition_description === conditionDesc[3]) {
        properties[i].condition_id = conditionDescId[3];
      }
  
      else if (properties[i].condition_description === conditionDesc[4]) {
        properties[i].condition_id = conditionDescId[4];
      }
  
      else if (properties[i].condition_description === conditionDesc[5]) {
        properties[i].condition_id = conditionDescId[5];
      }
    }
  
    return properties;
  
  }




function addLayer() {
	
 let serviceUrl = document.location.origin + "/api/userId";
 console.log(serviceUrl);
 $.ajax({
  url: serviceUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
   
   let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 

// define icon
          let testMarkerGreen = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'green'
		});
		let testMarkerPink = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'pink'
		});
		let testMarkerBlue = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'blue'
		});
		let testMarkerOrange = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'orange'
		});
		let testMarkerGray = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'gray'
		});
		let testMarkerRed = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'red'
		});
	
   // Call the API to get the nearest assets
      let lastUrl = document.location.origin + "/api/geojson/userAssets/"+current_user_id;
      $.ajax({
        url: lastUrl,
        crossDomain: true,
        success: function(result) {
          // clear all layers from the map
          
		
          
          // add these 5 assets on the map
          last5AssetsLayer = L.geoJSON(result, {
            // use point to layer to create the points
            pointToLayer: function (feature, latlng) {
				 let iconColor;
          if (feature.properties.condition_description == conditionDescription[0]){
            iconColor = testMarkerGreen;
          }
          else if (feature.properties.condition_description == conditionDescription[1]){
            iconColor = testMarkerPink;
          }
          else if (feature.properties.condition_description == conditionDescription[2]){
            iconColor = testMarkerBlue;
          }
          else if (feature.properties.condition_description == conditionDescription[3]){
            iconColor = testMarkerOrange;
          }
          else if (feature.properties.condition_description == conditionDescription[4]){
            iconColor = testMarkerGray;
          }
          else {
            iconColor = testMarkerRed;
          }
				
				
              return L.marker(latlng,{icon:iconColor}).bindPopup("<h2>Five Last Assets</h2>"
			  +"<h2>Asset Name: "+feature.properties.asset_name+"</h2>"
			  +"<h3>Condition: "+feature.properties.condition_description+"</h3>").openPopup();
           
		   }, // end of point to layer
          }).addTo(mymap);
          mymap.fitBounds(last5AssetsLayer.getBounds()); // zoom to this layer
           
        },
        error: function(error) {
          console.log(error);
        }
      });
  },
  error: function (errorThrown) {
   console.log("Error: " + errorThrown);
  }
 }); 
}







// function to debounce other functions - same as in utilities.js

function debounce(func, wait, immediate) {
    let timeout;
    return function() {
      const context = this, args = arguments;
      const later = function() {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
}