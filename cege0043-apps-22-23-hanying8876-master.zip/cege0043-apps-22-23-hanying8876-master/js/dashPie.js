"use strict";


function loadPieChart(){

    //removePieChart();

    console.log("Loading Pie Chart");
    // Dr Ellul's code:

  let width = document.getElementById("pieChart").clientWidth;
  let height = document.getElementById("pieChart").offsetHeight;
  console.log(width + " " + height);

  // Add the close button and an SVG element for the graph
  document.getElementById("pieChart").innerHTML = `
    <div class="h-100 w-100" style="box-sizing: border-box; overflow: hidden;">
      <svg fill="black" width="${width}" height="${height}" id="svg2" style="margin: 0; position: "relative;"></svg>
    </div>
  `;

  document.getElementById("pieChart").insertAdjacentHTML('afterbegin', `
  <h5 class="text-left">Asset Pie Chart</h5>
  <button id = button1 class="btn bg-gradient-primary btn-xs position-absolute top-0 end-0 mt-3 me-3" onclick="alertConditionDesc()" >condtion desc</button>
`);


console.log(userId)
  // URL for the AJAX request to retrieve the data.
  let ChartAddress ="/api/geojson/userAssets/" + 615;
  let PieChartURL = document.location.origin + ChartAddress;
     
  // download the data and create the pie chart

  // ** CODE ADAPTED FROM: https://d3-graph-gallery.com/graph/pie_annotation.html. Accessed on 23/04/2023.
  
  d3.json(PieChartURL).then(data => { 
    console.log(data);
    let features = data
    console.log(features)
    let properties = [];
    for (let i = 0; i < features.length; i++) {
        properties.push(features[i].properties);
    }
    console.log(properties);

    convertDesctoInt(properties, conditionDesc, conditionDescId);
    
    aggregateAssetIds(properties);



    //calculate the sum:

    let sumOfValues = Object.values(aggregatedIds).reduce((a, b) => a + b.length, 0);

     // tooltip to show the user the data properites when they hover over the bars.
    // code was adapted from: https://perials.github.io/responsive-bar-chart-with-d3/ accessed on 23/04/2023,
   
    const tooltip = d3.select("body")
        .append("div")
        .attr("class","d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .style("padding", "15px")
        .style("background", "rgba(0,0,0,0.6)")
        .style("border-radius", "5px")
        .style("color", "#fff")
        .text("a simple tooltip");


    // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
    var radius = Math.min(width, height) / 3 

    // append the svg object to the svg2 div.
    var svg = d3.select("#svg2")
                .append("svg")
                .attr("width", width)
                .attr("height", height)
                .append("g")
                .attr("transform", "translate(" + width * 0.3 + "," + height * 0.37 + ")");

    
    let colourSpecial = {
        1: "#FFD661", 
        2: "#61ABFF", 
        3: "#A661FF", 
        4: "#FF61D6",
        5: "#B8FF97",
        6: "#FC6C6C",
    };
        
        
    // set the color scale
    //var color = d3.scaleOrdinal()
                //.domain(data)
                //.range(Object.values(colorSpecial));



    // Compute the position of each group on the pie:
    var pie = d3.pie()
    .value(function(d) {return d.value.length; })
    var data_ready = pie(d3.entries(aggregatedIds))

    // shape helper to build arcs:
    var arcGenerator = d3.arc()
    .innerRadius(0)
    .outerRadius(radius)
    
    // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
    svg
    .selectAll('mySlices')
    .data(data_ready)
    .enter()
    .append('path')
    .attr('d', arcGenerator)
    .attr('fill', function(d){ return colourSpecial[d.data.key] })
    .attr("stroke", "black")
    .style("stroke-width", "2px")
    .style("opacity", 0.7)
    // append the tooltip to the slices so when the user hovers/clicks on the them, it shows the percentage.
    .on("mouseover", function(d, i) {
        let percentage = Math.round((d.data.value.length / sumOfValues) * 100);
        tooltip.html(`<strong>Percentage: </strong> ~${percentage}%`).style("visibility", "visible");
        d3.select(this)
        .style("fill", "#EEFF24")
      })
      .on("mousemove", function(){
        tooltip
          .style("top", (event.pageY-10)+"px")
          .style("left",(event.pageX+10)+"px");
      })
      .on("mouseout", function() {
        tooltip.html(``).style("visibility", "hidden");
        d3.select(this)
        .style("fill", function(d){ return colourSpecial[d.data.key] })
      })
      // we will also add a click functionality which highlights the asset bars in the bar chart which correspond to the bars in the pie chart.
      .on('click', function(d) {
        let assetIds = d.data.value;
        
        d3.selectAll(".bar")
          .filter(function(barD) { 
            // .includes is necessary because the filter function only checks for one bar at a time. 
            // since the asset Ids can be arrays, this means that the bar asset id will always be false.
            // (1 integer != an array of integers)
            // by using .includes, it checks if the id in the bar chart is within the array and highlights it.
            return assetIds.includes(barD.asset_id); 
          })
          .transition()
          .duration(500)
          .style("fill", "#EEFF24");
      
        setTimeout(function() {
          d3.selectAll(".bar")
            .filter(function(barD) { 
              return assetIds.includes(barD.asset_id); 
            })
            .transition()
            .style("fill", "#71EEB8");
        }, 1500);
      
        
      
    });

    // hand made legend - reference is the same as the one on graph.js
      // legend title.
    svg.append("text")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.3)
    .text("Asset Condition ID.")
    .style("font-size", "12px")
    .attr("alignment-baseline","middle");

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[1]);

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25 + 20)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[2]);

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25 + 40)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[3]);

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25 + 60)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[4]);

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25 + 80)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[5]);

    // 
    svg.append("rect")
    .attr("x", width * 0.3 )
    .attr("y", height * - 0.25 + 100)
    .attr("width", 15)
    .attr("height", 15)
    .style("fill", colourSpecial[6]);
    
    // Text for the legend

    // 1
    svg.
    append("text")
    .attr("x", width * 0.3 + 20 )
    .attr("y", height * - 0.25 + 9)
    .text("1")
    .style("font-size", "12px")
    .attr("alignment-baseline","middle");
    
    // 2
    svg.append("text")
    .attr("x", width *  0.3 + 20 )
    .attr("y", height * - 0.25 + 29)
    .text("2")
    .style("font-size", "12px")
    .attr("alignment-baseline","middle");


    // 3
     svg.
     append("text")
     .attr("x", width *  0.3 + 20 )
     .attr("y", height * - 0.25 + 49 )
     .text("3")
     .style("font-size", "12px")
     .attr("alignment-baseline","middle");
 
    // 4
     svg.append("text")
     .attr("x", width *  0.3 + 20 )
     .attr("y", height * - 0.25 + 69)
     .text("4")
     .style("font-size", "12px")
     .attr("alignment-baseline","middle");


    // 5
    svg.
    append("text")
    .attr("x", width *  0.3 + 20 )
    .attr("y", height * - 0.25 + 89)
    .text("5")
    .style("font-size", "12px")
    .attr("alignment-baseline","middle");
    
    // 6
    svg.append("text")
    .attr("x", width *  0.3 + 20 )
    .attr("y", height * - 0.25 + 109)
    .text("6")
    .style("font-size", "12px")
    .attr("alignment-baseline","middle");

 
    
    })
}



function wrap(text, width) {
  text.each(function() {
    let text = d3.select(this),
    words = text.text().split(/\s+/).reverse(),
    word,
    line = [],
    lineNumber = 0,
    lineHeight = 1.1, // ems
    y = text.attr("y"),
    dy = parseFloat(text.attr("dy")),
    tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
    while (word = words.pop()) {
      line.push(word);
      tspan.text(line.join(" "));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(" "));
        line = [word];
        tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
      }
    }
  });
}


// function to remove the pie chart.
function removePieChart(){
    document.getElementById("pieChart").innerHTML = "";

  }
  
