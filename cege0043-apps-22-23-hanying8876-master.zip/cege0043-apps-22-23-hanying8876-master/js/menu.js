"use strict";

 let last5AssetsLayer = [];
 let AssetConditionLayer=[];
 let last3AssetsLayer=[];
 let closest5AssetsLayer=[];
 
// List of best Condition

function bestCondition() {
  let serviceUrl = document.location.origin + "/api/geojson/assetsInGreatCondition";
  $.ajax({
    url: serviceUrl,
    success: function(result) {
      let assets = result;
      let tableHTML = "<table id='data' class='display' style='width:100%; margin-top:60px;'>";
      tableHTML += "<thead><tr><th><h2>Asset ID</h2></th><th><h2>Asset Name</h2></th><th><h2>Installation Date</h2></th><th><h2>Latitude</h2></th><th><h2>Longitude</h2></th><th><button onclick='closeTable()' class='close-button'>X</button></th></tr></thead><tbody>";

      for (let i = 0; i < assets[0].array_to_json.length; i++) {
        tableHTML += "<tr>";
        tableHTML += "<td>" + assets[0].array_to_json[i].id + "</td>";
        tableHTML += "<td>" + assets[0].array_to_json[i].asset_name + "</td>";
        tableHTML += "<td>" + assets[0].array_to_json[i].installation_date + "</td>";
        tableHTML += "<td>" + assets[0].array_to_json[i].location.coordinates[1] + "</td>";
        tableHTML += "<td>" + assets[0].array_to_json[i].location.coordinates[0] + "</td>";
        tableHTML += "</tr>";
      }

      tableHTML += "</tbody></table>";
      document.getElementById("tablediv").innerHTML = tableHTML;
      createDataTable();
    },
    error: function() {
      // Handle error
    }
  });

  function createDataTable() {
    $("#data").DataTable({
      paging: true,
      pageLength: 12,
      lengthChange: true,
      lengthMenu: [5, 10, 15],
      scrollX: true, // Use true instead of "100%"
      dom: "Bfrtip",
      buttons: ["copyHtml5", "excelHtml5", "csvHtml5", "pdfHtml5"],
      responsive: true // Add responsive option for smaller screens
    });
  }
}

function closeTable() {
  document.getElementById("tablediv").innerHTML = "";
}




 // help page
 
let helpurl = document.location.origin + "/app/help.html"
 
 
 // User Ranking
 function UserRanking() {
 let idUrl = document.location.origin + "/api/userId";
 console.log(idUrl);
 $.ajax({
  url: idUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
	
   let serviceUrl=  document.location.origin + "/api/geojson/userRanking/" + current_user_id;
        
   $.ajax({
      url:serviceUrl,
      async: false,
      crossDomain:true,
      success: function(result){
        	let ranking;
			 
        	ranking = result[0].array_to_json[0].rank;

            alert("Your ranking based on number of condition reports created is: " + ranking );
                             
       },
       error: function (errorThrown) {
           console.log("Error: " + errorThrown);
       }
   }); 
  },
  error: function (errorThrown) {
   console.log("Error: " + errorThrown);
  }
 }); 
}






// function used to add 5 closest assets

function addLayerClosest() {
	removeAllLayers()
  navigator.geolocation.getCurrentPosition(
    function (position) {
      let lat = position.coords.latitude;
      let lng = position.coords.longitude;
      console.log("test");
	  
	  //condition
	  let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 
	  
	  
      // Call the API to get the nearest assets
      let serviceUrl = document.location.origin + `/api/geojson/userFiveClosestAssets/${lat}/${lng}`;
      $.ajax({
        url: serviceUrl,
        crossDomain: true,
        success: function(result) {
          // clear all layers from the map
          if (AssetsLayer) {
            mymap.removeLayer(AssetsLayer);
          }
          if (closest5AssetsLayer) {
            mymap.removeLayer(closest5AssetsLayer);
            
          }
          if (last5AssetsLayer) {
            mymap.removeLayer(last5AssetsLayer);
            
          }
          if (last3AssetsLayer) {
            mymap.removeLayer(last3AssetsLayer);
          }
          // define icon
          let testMarkerBlack = L.AwesomeMarkers.icon({
            icon: 'play',
            markerColor: 'black'
          });
          // add these 5 assets on the map
          closest5AssetsLayer = L.geoJSON(result, {
            // use point to layer to create the points
            pointToLayer: function (feature, latlng) {
              return L.marker(latlng,{icon:testMarkerBlack}).bindPopup("<h2>Five Closest Assets</h2>"+"<h2>Asset Name: "
			  +feature.properties.asset_name+"</h2>"
			  +"<h3>Condition: "+feature.properties.condition_description+"</h3>").openPopup();
			  
			  
			
            }, // end of point to layer
          }).addTo(mymap);
          mymap.fitBounds(closest5AssetsLayer.getBounds()); // zoom to this layer
          
        },
        error: function(error) {
          console.log(error);
        }
      });
    },
    function(error) {
      console.log(error);
    }
  );
}




// remove 5 closest assets
function removeLayerClosest(){
    try {
        alert('The 5 closest assets will be removed.');
        mymap.removeLayer(closest5AssetsLayer);
        AssetsLayer.addTo(mymap);
    } catch (err) {
        alert("Sorry, you haven't loaded the 5 closest assets.");
        console.log(err)
    }
};
 
 
 

 
// function used to add 5 closest Last
 
function addLayerLast() {
	removeAllLayers()
 let serviceUrl = document.location.origin + "/api/userId";
 console.log(serviceUrl);
 $.ajax({
  url: serviceUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
   
   let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 

// define icon
          let testMarkerGreen = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'green'
		});
		let testMarkerPink = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'pink'
		});
		let testMarkerBlue = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'blue'
		});
		let testMarkerOrange = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'orange'
		});
		let testMarkerGray = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'gray'
		});
		let testMarkerRed = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'red'
		});
	
   // Call the API to get the nearest assets
      let lastUrl = document.location.origin + "/api/geojson/lastFiveConditionReports/"+current_user_id;
      $.ajax({
        url: lastUrl,
        crossDomain: true,
        success: function(result) {
          // clear all layers from the map
          if (AssetsLayer) {
            mymap.removeLayer(AssetsLayer);
          }
          if (closest5AssetsLayer) {
            mymap.removeLayer(closest5AssetsLayer);
            
          }
          if (last5AssetsLayer) {
            mymap.removeLayer(last5AssetsLayer);
            
          }
          if (last3AssetsLayer) {
            mymap.removeLayer(last3AssetsLayer);
          }
		  
		
          
          // add these 5 assets on the map
          last5AssetsLayer = L.geoJSON(result, {
            // use point to layer to create the points
            pointToLayer: function (feature, latlng) {
				 let iconColor;
          if (feature.properties.condition_description == conditionDescription[0]){
            iconColor = testMarkerGreen;
          }
          else if (feature.properties.condition_description == conditionDescription[1]){
            iconColor = testMarkerPink;
          }
          else if (feature.properties.condition_description == conditionDescription[2]){
            iconColor = testMarkerBlue;
          }
          else if (feature.properties.condition_description == conditionDescription[3]){
            iconColor = testMarkerOrange;
          }
          else if (feature.properties.condition_description == conditionDescription[4]){
            iconColor = testMarkerGray;
          }
          else {
            iconColor = testMarkerRed;
          }
				
				
              return L.marker(latlng,{icon:iconColor}).bindPopup("<h2>Five Last Assets</h2>"
			  +"<h2>Asset Name: "+feature.properties.asset_name+"</h2>"
			  +"<h3>Condition: "+feature.properties.condition_description+"</h3>").openPopup();
           
		   }, // end of point to layer
          }).addTo(mymap);
          mymap.fitBounds(last5AssetsLayer.getBounds()); // zoom to this layer
           
        },
        error: function(error) {
          console.log(error);
        }
      });
  },
  error: function (errorThrown) {
   console.log("Error: " + errorThrown);
  }
 }); 
}
 
 
  function removeLayerLast(){
    try {
        alert('The 5 assets with last report information will be removed.');
        mymap.removeLayer(last5AssetsLayer);
        AssetsLayer.addTo(mymap);
    } catch (err) {
        alert("Sorry, you haven't loaded the 5 assets with last report information.");
        console.log(err)
    }
};
 
 
 
 // function used to add not Rate
 function addLayerRate(){
	removeAllLayers()
 let idUrl = document.location.origin + "/api/userId";
 console.log(idUrl);
 $.ajax({
  url: idUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
   
   let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 

// define icon
          let testMarkerGreen = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'green'
		});
		let testMarkerPink = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'pink'
		});
		let testMarkerBlue = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'blue'
		});
		let testMarkerOrange = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'orange'
		});
		let testMarkerGray = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'gray'
		});
		let testMarkerRed = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'red'
		});
	
   // Call the API to get the nearest assets
      let lastUrl = document.location.origin + "/api/geojson/conditionReportMissing/"+current_user_id;
      $.ajax({
        url: lastUrl,
        crossDomain: true,
        success: function(result) {
          // clear all layers from the map
          if (AssetsLayer) {
            mymap.removeLayer(AssetsLayer);
          }
          if (closest5AssetsLayer) {
            mymap.removeLayer(closest5AssetsLayer);
            
          }
          if (last5AssetsLayer) {
            mymap.removeLayer(last5AssetsLayer);
            
          }
          if (last3AssetsLayer) {
            mymap.removeLayer(last3AssetsLayer);
          }
		  
		
          
          // add these 5 assets on the map
          last5AssetsLayer = L.geoJSON(result, {
            // use point to layer to create the points
            pointToLayer: function (feature, latlng) {
				 let iconColor;
          if (feature.properties.condition_description == conditionDescription[0]){
            iconColor = testMarkerGreen;
          }
          else if (feature.properties.condition_description == conditionDescription[1]){
            iconColor = testMarkerPink;
          }
          else if (feature.properties.condition_description == conditionDescription[2]){
            iconColor = testMarkerBlue;
          }
          else if (feature.properties.condition_description == conditionDescription[3]){
            iconColor = testMarkerOrange;
          }
          else if (feature.properties.condition_description == conditionDescription[4]){
            iconColor = testMarkerGray;
          }
          else {
            iconColor = testMarkerRed;
          }
				
				
              return L.marker(latlng,{icon:iconColor}).bindPopup("<h2>Five Last Assets</h2>"
			  +"<h2>Asset Name: "+feature.properties.asset_name+"</h2>"
			  +"<h3>Condition: "+feature.properties.condition_description+"</h3>").openPopup();
           
		   }, // end of point to layer
          }).addTo(mymap);
          //mymap.fitBounds(last3AssetsLayer.getBounds()); // zoom to this layer
           
        },
        error: function(error) {
          console.log(error);
        }
      });
  },
  error: function (errorThrown) {
   console.log("Error: " + errorThrown);
  }
 }); 
}
 
  function removeLayerRate() {
    try {
        alert('The layer will be removed.');
        mymap.removeLayer(last3AssetsLayer);
        AssetsLayer.addTo(mymap);
    } catch (err) {
        alert("Sorry, you haven't loaded the report information.");
        console.log(err)
    }
};
 