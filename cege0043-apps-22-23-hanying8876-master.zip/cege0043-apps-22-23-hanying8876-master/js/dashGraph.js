"use strict";

function loadGraph(){
  
  let idUrl = document.location.origin + "/api/userId";
 console.log(idUrl);
 $.ajax({
  url: idUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
  }
}); 	
	let dataURL = document.location.origin + "/api/geojson/userAssets/" + current_user_id;
	// get the width and height of the wraper
	let widtha = document.getElementById("barGraphContainer").clientWidth;
	let heighta = document.getElementById("barGraphContainer").offsetHeight;

	// Add an SVG element for the graph
	document.getElementById("barGraph").innerHTML=
	`<div  class="h-100 w-100"><svg fill="blue" width="`+widtha+`" height="`+heighta+`" id="svg1"></svg></div>`;

	// create an SVG container for the graph
    // g is a grouping element
    let marginTop = 10;
    let marginBottom = 60;
    let marginLeft = 20;
    let marginRight = 20;

	let svg = d3.select("#svg1"),
		margin  = {top: marginTop, right: marginRight, bottom: marginBottom, left: marginLeft},
		width   = svg.attr("width") - marginLeft - marginRight,
		height  = svg.attr("height") - marginTop - marginBottom,
		x       = d3.scaleBand().rangeRound([0, width]).padding(0.2),
		y       = d3.scaleLinear().rangeRound([height, 0]),
		g       = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

	// download the data and create the graph
	d3.json(dataURL).then(data => {
    	data = data[0].features; // // extract the data from the GeoJSON format
		for (let i = 0; i < data.length; i++) {
			data[i].properties["condition_value"] = conditionObject[data[i].properties.condition_description];
			// add a new property to each data point with the corresponding condition value 
		}

		// define the x and y scales
		x.domain(data.map(d => d.properties.asset_name));
		y.domain([0, d3.max(data, d => d.properties.condition_value)]);
		// draw the x and y axis
		g.append("g")
			.attr("class", "axis axis-x")
			.attr("transform", `translate(0,${height})`)
			.call(d3.axisBottom(x))
			.selectAll(".tick text")  
			.style("text-anchor", "middle")
			.call(wrap,x.bandwidth());
		g.append("g")
			.attr("class", "axis axis-y")
			.call(d3.axisLeft(y).ticks(d3.max(data, d => d.properties.condition_value)).tickSize(8));
		// draw the bar graph
		g.selectAll(".bar")
			.data(data)
			.enter().append("rect")
			.attr("class", "bar")
			.attr("x", d => x(d.properties.asset_name))
			.attr("y", d => y(d.properties.condition_value))
			.attr("width", x.bandwidth())
			.attr("height", d => height - y(d.properties.condition_value))
			.attr('fill', 'blue')
		// add x and y axis labels
		g.append("text")
			.attr("class", "x label")
			.attr("x", width / 2)
			.attr("y", height + margin.top + 40)
			.attr("text-anchor", "middle")
			.attr("fill", "#555")
			.style("font-family", "Arial")
			.style("font-size", "16px")
			.text("Asset Name");
		g.append("text")
			.attr("class", "y label")
			.attr("y", 15)
			.attr("dy", ".75em")
			.attr("text-anchor", "end")
			.attr("transform", "rotate(-90)")
			.attr("fill", "#555")
			.style("font-family", "Arial")
			.style("font-size", "16px")
			.text("Condition Value");
	})
	.catch(err => {
		// handle any errors that occur during data loading
		svg.append("text")         
		.attr("y", 20)
		.attr("text-anchor", "left")  
		.style("font-size", "10px") 
		.style("font-weight", "bold")  
		.text(`Couldn't open the data file: "${err}".`);
	});

	
	



	
  }
}); 
  
  
  
  

}






// separate function to wrap the legend entries
function wrap(text, width) {
    text.each(function() {
        let text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0,
        lineHeight = 1.1, // ems
        y = text.attr("y"),
        dy = parseFloat(text.attr("dy")),
        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            if (tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }
        }
    });
}