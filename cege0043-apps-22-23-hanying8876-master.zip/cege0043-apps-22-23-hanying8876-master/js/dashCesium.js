"use strict"

function loadVectorLayer() {
  // Fetch user_id from API
  let idUrl = document.location.origin + "/api/userId";
  $.ajax({
    url: idUrl,
    dataType: "json",
    success: function (data) {
      let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let user_id = userID;

      // Fetch user assets using user_id
      $.ajax({
        url: document.location.origin + "/api/geoJSON/userAssets/" + user_id,
        dataType: "json",
        success: function (data) {
          // Convert the asset data to GeoJSON format
          const geojsonData = {
            type: "FeatureCollection",
            features: data,
          };

          let dataSource = new Cesium.GeoJsonDataSource("Assets");
          viewer.dataSources.add(dataSource);
          dataSource.load(geojsonData).then((dataSource) => {
            // Apply custom style for each entity
            dataSource.entities.values.forEach((entity) => {
              const condition_id = entity.properties.condition_id.getValue();
              const color = getColorByCondition(condition_id);
entity.billboard = undefined;

              entity.point = new Cesium.PointGraphics({
                color: color,
                pixelSize: 10,
                outlineColor: Cesium.Color.BLACK,
                outlineWidth: 1,
              });
            });

            viewer.flyTo(dataSource);
          });
        },
        error: function (xhr, textStatus, errorThrown) {
          console.log("Error fetching user assets:", errorThrown);
        },
      });
    },
    error: function (xhr, textStatus, errorThrown) {
      console.log("Error fetching user ID:", errorThrown);
    },
  });

  function getColorByCondition(condition_id) {
    if (condition_id === 1) {
      return Cesium.Color.GREEN;
    } else if (condition_id === 2) {
      return Cesium.Color.YELLOW;
    } else if (condition_id === 3) {
      return Cesium.Color.ORANGE;
    } else if (condition_id === 4 || condition_id === 5) {
      return Cesium.Color.PINK;
    } else {
      return Cesium.Color.GRAY;
    }
  }
}