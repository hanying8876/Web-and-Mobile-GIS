"use strict"; 

 
 function trackLocation() {
  if (navigator.geolocation) {
    // test to see if there is an active tracking and clear it if so
    // so that we don’t have multiple tracking going on
    try {
      navigator.geolocation.clearWatch(geoLocationID);
    } catch (e) {
      console.log(e);
    }
    // clear any existing data from the map
    removeTracks();

    const options = {
      enableHighAccuracy: true,
      maximumAge: 40000,
      timeout: 40000,
    };
  
 geoLocationID = navigator.geolocation.watchPosition(
      (position) => {
        showPosition(position);
      },
      errorPosition,
      options
    );
 
  } else {
    document.getElementById("showLocation").innerHTML = "Geolocation is not supported by this browser.";
  }
}


function showPosition(position) {

  //track self position
trackLocationLayer.push(L.marker([position.coords.latitude,position.coords.longitude]).addTo(mymap)); 
mymap.flyTo([position.coords.latitude,position.coords.longitude],16);

  
  if (markers.length === 0) {
    console.log("No markers found on the map.");
    return;
  }

let minDistance = Infinity;
let closestMarker;
 let userLatLng = L.latLng(position.coords.latitude, position.coords.longitude);
const minDistanceThreshold = 0.25;

 

        markers.forEach(marker => {
          const assetLatLng = marker.getLatLng();
          const distance = calculateDistance(
          userLatLng.lat, userLatLng.lng,
          assetLatLng.lat, assetLatLng.lng,
           "K" 
        );


          if (distance < minDistance) {
            minDistance = distance;
            closestMarker = marker;
          }
        });
             if (closestMarker && minDistance <= minDistanceThreshold) {
          closestMarker.openPopup();
        }
      }
      
    

function errorPosition(error){ 
	alert(error);
}



function calculateDistance(lat1, lon1, lat2, lon2, unit) {
 let radlat1 = Math.PI * lat1/180;
 let radlat2 = Math.PI * lat2/180;
 let radlon1 = Math.PI * lon1/180;
 let radlon2 = Math.PI * lon2/180;
 let theta = lon1-lon2;
 let radtheta = Math.PI * theta/180;
 let dist= Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
 dist = Math.acos(dist);
 dist = dist * 180/Math.PI; // convert the degree value returned by acos back to degrees from radians
 dist = (dist/360)* 2 * Math.PI * 3956; // ((subtended angle in degrees)/360) * 2 * pi * radius )
// where radius of the earth is 3956 miles
 if (unit=="K") { dist = dist * 1.609344 ;} // convert miles to km
 if (unit=="N") { dist = dist * 0.8684 ;} // convert miles to nautical miles
 return dist;
}




//remove tracking

function removePositionPoints() {

	navigator.geolocation.clearWatch(geoLocationID);
	removeTracks();
}

function removeTracks(){
	
	for (let i=trackLocationLayer.length-1; i > -1;i--) {
	console.log("removing point "+i + " which has coordinates "+trackLocationLayer[i].getLatLng());
	mymap.removeLayer(trackLocationLayer[i]);
	// if you want to totally remove the points, you can also remove them
	// from the array where they are stored, using the pop command
	trackLocationLayer.pop();
	}
}

//adjust location
function userZoom() {

if (navigator.geolocation) {
  // Get user location
  navigator.geolocation.getCurrentPosition(function(position) {
    // User location found, zoom and center the map
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    if (map) {
      map.setView([lat, lng], 10);
    } else {
      alert("No map layer is loaded.");
    }
  });
} else {
  // User location not defined, generate alert
  alert("User location is not defined.");
}

	
}


