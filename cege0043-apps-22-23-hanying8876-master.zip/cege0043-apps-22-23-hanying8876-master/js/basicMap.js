"use strict";



let user_id
let mymap;
 // create a custom popup    
    let popup = L.popup();

// create an array to store all the location tracking points
let trackLocationLayer = [];
// store the ID of the location tracker so that it can be used to switch the location tracking off
let geoLocationID;

function processWindowResize() {
 console.log("resize");
}

function refreshMap(){
    // needs a timeout to allow the new size of the div to settle
    setTimeout(function(){ mymap.invalidateSize()}, 400);
}

function loadMap() {
    
    mymap = L.map('mapid').setView([51.505, -0.09], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(mymap);

window.addEventListener('resize', setMapClickEvent);
setMapClickEvent(); 
 

  
	
}	



function removeAllLayers() {
const firstLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
maxZoom: 19,
attribution: '&copy; <a href=" ">OpenStreetMap</a >'
}).addTo(mymap);


mymap.eachLayer(function(layer) {
mymap.removeLayer(layer);
});


firstLayer.addTo(mymap);
}



function getUserId() {
 let serviceUrl = document.location.origin + "/api/userId";
 console.log(serviceUrl);
 $.ajax({
  url: serviceUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
  },
  error: function (errorThrown) {
   console.log("Error: " + errorThrown);
  }
 });
}




let popUpHTML
let width; // NB – keep this as a global variable
let AssetsLayer;
let CurrentAssetsLayer;

function setMapClickEvent() {
 // get the window width
 width = $(window).width();

 if (width < 768) { 
 if (CurrentAssetsLayer){
		mymap.removeLayer(CurrentAssetsLayer); 
	}
//the condition capture –anything smaller than 768px is defined as 'small' by bootstrap
 
 // cancel the map onclick event using off ..
 mymap.off('click',onMapClick)
 // set up a point with click functionality
 // so that anyone clicking will add asset condition information
 setUpPointClick();
 // track location
 trackLocation();
}
 else { // the asset creation page

 if (AssetsLayer){
		mymap.removeLayer(AssetsLayer); 
	}
 // the on click functionality of the MAP should pop up a blank asset creation form
 mymap.on('click', onMapClick);
 
 removeTracks();
 CurrentUserAssetPoints();

}
}



function setUpPointClick() {
 
let serviceUrl = document.location.origin + "/api/userId";
// let current_user_id;
$.ajax({url: serviceUrl, crossDomain: true,success: function(result){
	console.log(result); // check that the data is correct
	let current_user_id;
	let listOfAssets = []
	let Assets;
	current_user_id = result[0].user_id;
	loadAssets(current_user_id,listOfAssets,Assets);
    } // end of the inner function
  }); // end of the ajax request 
}

function getConditionPopupHTML(Condition_id,Condition_Description){
let htmlString = '';
for (let i = 0; i < Condition_id.length - 1; i++) {
    htmlString = htmlString + '<input type="radio" name="asset_condition_options" id = '+ Condition_id[i] + ' value="'+Condition_Description[i]+'"/>'+Condition_Description[i]+'<br/>';
}
htmlString = htmlString + '<button id="saveCondition" onclick="saveConditionInformation();">Save Condition</button>';

return htmlString;
}


function getAssetPopupHTML(asset_name,installation_date,asset_id,user_id){
let htmlString = "<DIV id='popup'"+ asset_id+ "><h2 id=asset_name value="+ asset_name+">" + asset_name + "</h2><br>"; 
htmlString = htmlString + "<h3>"+installation_date + "</h3><br>";
// now include a hidden element with the previous condition value
htmlString = htmlString + `<div id=asset_id name="${asset_id}" hidden> ${asset_id} </div>`;
// and a hidden element with the ID of the asset so that we can insert the condition with the correct asset later
htmlString = htmlString + `<div id=user_id name="${user_id}" hidden> ${user_id} </div>`;
htmlString = htmlString + "</div>";
return htmlString;
}



let markers=[];
function loadAssets(current_user_id,listOfAssets,Assets,assetsname) {
 // first check if the thing is loaded already
  for (let i=0;i<listOfAssets.length ;i++){
  if (listOfAssets[i].assetsName == assetsname){
      console.log("Sensors loaded");
      alert("Sensors already loaded");
      return;
  }
}

let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 

// define different icons
		let testMarkerGreen = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'green'
		});
		let testMarkerPink = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'pink'
		});
		let testMarkerBlue = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'blue'
		});
		let testMarkerOrange = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'orange'
		});
		let testMarkerGray = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'gray'
		});
		let testMarkerRed = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'red'
		});



let AssetsURL = document.location.origin + "/api/geojson/userAssets/" + current_user_id;
$.ajax({
    url: AssetsURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct

    		let popuphtml_condition = getConditionPopupHTML(conditionId,conditionDescription);
    		// console.log(popuphtml_condition);
        AssetsLayer = L.geoJson(result, {
            pointToLayer:
                function (feature, latlng) {
					
              let iconColor;
          if (feature.properties.condition_description == conditionDescription[0]){
            iconColor = testMarkerGreen;
          }
          else if (feature.properties.condition_description == conditionDescription[1]){
            iconColor = testMarkerPink;
          }
          else if (feature.properties.condition_description == conditionDescription[2]){
            iconColor = testMarkerBlue;
          }
          else if (feature.properties.condition_description == conditionDescription[3]){
            iconColor = testMarkerOrange;
          }
          else if (feature.properties.condition_description == conditionDescription[4]){
            iconColor = testMarkerGray;
          }
          else {
            iconColor = testMarkerRed;
          }
		  
          const marker= L.marker(latlng,{icon:iconColor}).bindPopup(getAssetPopupHTML(feature.properties.asset_name,feature.properties.installation_date,feature.properties.asset_id,current_user_id)+popuphtml_condition);
	markers.push(marker);
    return marker;           
                }, 
        }).addTo(mymap);
        mymap.fitBounds(AssetsLayer.getBounds());
    }
}); 


}





function CurrentUserAssetPoints(current_user_id,Assets,assetsname) {
 let idUrl = document.location.origin + "/api/userId";
 console.log(idUrl);
 $.ajax({
  url: idUrl,
  type: "GET",
  success: function (data) {
   // console.log(data);
   let userID = data[0]["user_id"];
   console.log("Your user ID is: " + userID); // Print the user ID to the console
   
   let current_user_id = userID;
let conditionId = [];
let conditionDescription = [];
let ConditionDeatailURL = document.location.origin + "/api/conditionDetails";
$.ajax({
    url: ConditionDeatailURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct
    for (let i = 0; i < result.length; i++) {
    let obj = result[i];
    let id = obj.id;
    conditionId.push(id);
    let condition_description = obj.condition_description;
    conditionDescription.push(condition_description);
}
  }
}); 

// define different icons
	
		let testMarkerWhite = L.AwesomeMarkers.icon({
			icon: 'play',
			markerColor: 'white'
		});

let AssetsURL = document.location.origin + "/api/geojson/userAssets/" + current_user_id;
$.ajax({
    url: AssetsURL, crossDomain: true, success: function (result) {
        console.log(result); // check that the data is correct

    		
        CurrentAssetsLayer = L.geoJson(result, {
            pointToLayer:
                function (feature, latlng) {
					
          return L.marker(latlng, {icon: testMarkerWhite}).bindPopup("<h2>Assets Information</h2>"+"<h2>Asset Name: "
			  +feature.properties.asset_name+"</h2>"
			  +"<h3>Installation Date: "+feature.properties.installation_date+"</h3>"
			  +"<h3>Condition: "+feature.properties.condition_description+"</h3>");  }, 
        }).addTo(mymap);
        mymap.fitBounds(CurrentAssetsLayer.getBounds());
    }
}); 

  }
}); 


}





function onMapClick(e) {
 let formHTML = assetFormHtml();
 
formHTML=formHTML.replace("{LAT}", e.latlng.lat.toFixed(6));
formHTML=formHTML.replace("{LNG}", e.latlng.lng.toFixed(6));

 popup
 .setLatLng(e.latlng)
 .setContent("You clicked the map at " + e.latlng.toString()+"<br>"+formHTML)
 .openOn(mymap);
 }
 
 
 function assetFormHtml() {
let mylet = '<label for="asset_name">Asset name</label><input type="text" size="25" id="asset_name"/><br />'+
'<label for="installation_date">installation_date</label><input type="date" size="25" id="installation_date"/><br />'+
''+
''+
'<br />'+
'<br />'+
'<label for="latitude">Latitude</label><input type="text" size="25" id="latitude" value="{LAT}"/><br />'+
'<label for="longitude">Longitude</label><input type="text" size="25" id="longitude" value="{LNG}"/><br />'+
''+
''+
'<p>Click here to upload the data</p>'+
'<button id="saveAsset" onclick="saveNewAsset()">Start Asset Data Upload</button>'+
'<br />'+
'<br />'+
'<div id="responseDIV">The result of the upload goes here</div>'+
'<div id="user_id" style="display: none;">1</div>'+
'<br />'+
'<br />'+
''+
'<hr>'+
'<hr>'+
''+
'<label for="deleteID">Delete ID</label><input type="text" size="25" id="deleteID"/><br />'+
'<button id="deleteAsset" onclick="deleteSingleAsset()">Delete Record</button>'+
'<div id="deleteAssetResponse">The result of the upload goes here</div>';
 
return mylet;
}


